name = input("Enter student name: ")
subjects = ("Maths", "python", "English", "java", "c++")
marks = (88,98,87,100,99)


print(f"Student Name: {name}")
print(f"Student Name Uppercase: {name.upper()}")
print(f"Subjects: {subjects}")
print(f"Marks: {marks}")

total = sum(marks)
print("Total Marks: ",total)

total = sum(marks)
average = total / len(marks)
print(average)

highest = max(marks)
print(highest)

lowest = min(marks)
print(lowest)

if 100 in marks:
    print("yes")
else:
    print("No")


if average>=90:
    Grade="A"
elif average >= 80:
    Grade="B"
elif average >= 70:
    Grade="C"
elif average >= 60:
    Grade="D"
else:
    Grade = "fail"

    
print("=================================")
print("STUDENT REPORT CARD")
print("=================================")

print("Student Name: ",name)
print("subject             marks")
print("math                  88  ")
print("python                98  ")
print("English               87  ")
print("Java                  100 ")
print("C++                   99  ")

print("total marks: ",total)
print("average: ",average)
print("Highest: ",highest)
print("lowest: ",lowest)
print("Grade: ",Grade)

print("===================================")